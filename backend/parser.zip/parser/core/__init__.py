__all__ = ("settings",
            "DataManager",
           )

from core.settings import settings
from core.data_manager import DataManager
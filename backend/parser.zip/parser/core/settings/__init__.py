__all__ = ("settings",)

from core.settings.config import settings